<?php 
session_start();
include_once 'db.php';?>
<!DOCTYPE html>
<html>
<head>
    <title>first php page</title>
     <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
  <script src="//ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <?php if(isset($_SESSION["userid"])) { 
                    ?>
                 Welcome <?php echo $_SESSION["name"]; ?>. Click here to <a href="logout.php" tite="Logout">Logout.</a>
                <?php
                }else{
                  echo "<h1>Please login first .</h1>";  
                } 
                ?>
                <ul>
                    <li><a href="register.php">Register</a></li>
                    <li><a href="login.php">login</a></li>
                </ul>
            </div>
        </div>
    </div>

</body>
</html>