<?php include_once 'db.php';
if(isset($_POST['save']))
{
    $username = $_POST['username'];
    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $phoneno = $_POST['phoneno'];
    $gender = $_POST['gender'];
    $address = $_POST['address'];
    mysqli_query($conn,"INSERT INTO register (username,firstname,lastname,email,password,phoneno,gender,address) VALUES ('$username','$firstname', '$lastname','$email','$password','$phoneno','$gender','$address')");
    echo "<script>alert('data successfully Inserted');</script>";
}
    ?>
<!DOCTYPE html>
<html>
<head>
    <title>first php page</title>
     <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
  <script src="//ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
       <script>
function checkemailAvailability() {
$("#loaderIcon").show();
jQuery.ajax({
url: "check_availability.php",
data:'emailid='+$("#emailid").val(),
type: "POST",
success:function(data){
$("#email-availability-status").html(data);
$("#loaderIcon").hide();
},
error:function (){}
});
}

function checkusernameAvailability() {
$("#loaderIcon").show();
jQuery.ajax({
url: "check_availability.php",
data:'username='+$("#username").val(),
type: "POST",
success:function(data){
$("#username-availability-status").html(data);
$("#loaderIcon").hide();
},
error:function (){}
});
}

    </script>
</script>
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <form method="post" name="loginForm" id="loginForm">
    <div class="form-group">
       <input type="text" name="username" id="username" value="" onBlur="checkusernameAvailability()" class="form-control" placeholder="username" required />
        <span id="username-availability-status"></span>
    </div>
    <div class="form-group">
        <input type="text" name="firstname" class="form-control" placeholder="firstname" required="">
    </div>
    <div class="form-group">
        <input type="text" name="lastname" class="form-control" placeholder="lastname" required="">
   </div>
   <div class="form-group">
       <input type="email" name="email" id="emailid" onBlur="checkemailAvailability()" value="" class="form-control" placeholder="email" required />
        <span id="email-availability-status"></span> 
   </div>
   <div class="form-group">
        <input type="password" name="password" class="form-control" placeholder="password" required="">
   </div>
   <div class="form-group">
        <input type="number" name="phoneno" class="form-control" placeholder="phoneno" required=""> 
   </div>
   <div class="form-group">
        Male<input type="radio" name="gender" class="" required="" value="male" checked="checked">
        FeMale<input type="radio" name="gender" class="" required="" value="female">
   </div>
   <div class="form-group">
       <textarea class="form-control" name="address" placeholder="Enter Your Massage" required=""></textarea>
   </div>
   <div class="form-group">
        <input type="submit" name="save" class="form-control btn btn-primary" value="submit">
   </div>
</form>                
            </div>
            <div class="col-md-6"></div>
        </div>
    </div>

</body>
</html>