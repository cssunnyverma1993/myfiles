<?php 
session_start();
  include_once 'db.php';?>
  <!DOCTYPE html>
  <html>
    <head>
      <title>first php page</title>
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
      <script src="//ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
      </head>
            <body>
            <div class="col-md-12">
              <nav class="navbar navbar-default">
                <div class="container-fluid">
                   <?php 
                    $userid=$_SESSION["userid"];
                    $result = mysqli_query($conn,"SELECT * FROM register WHERE userid='$userid'");
                    $row = mysqli_fetch_array($result);
                    ?>
                    <?php if(isset($_SESSION["userid"])) { ?>
                    <h1>Welcome <?php echo $_SESSION["name"]; ?>. Click here to <a href="logout.php" tite="Logout">Logout.</a></h1>
                    <?php
                  }else
                  {
                    echo "<h1>Please login first .</h1>";  } ?>
                   <div class="col-md-6">
                    <form method="post" name="loginForm" id="loginForm">
                    <div class="form-group">
                    <label>username</label>
                    <input type="text" value=" <?php echo $row['username'];?>" class="form-control" />
                    </div>
                    <div class="form-group">
                    <label>firstname</label>
                    <input type="text" name="firstname" class="form-control" value="<?php echo $row['firstname'];?>">
                    </div>
                    <div class="form-group">
                    <label>lastname</label>
                    <input type="text" name="lastname" class="form-control" value=" <?php echo $row['lastname'];?>">
                    </div>
                    </div>
                    <div class="col-md-6">
                    <div class="form-group">
                    <label>email</label>
                    <input type="email" name="email"  value="<?php echo $row['email'];?>" class="form-control">
                    </div>
                    <div class="form-group">
                    <label>Phone no</label>
                    <input type="text" name="phoneno" class="form-control" value="<?php echo $row['phoneno'];?>"> 
                    </div>
                    <div class="form-group">
                    <label>gender</label>
                    <input type="text" name="password" class="form-control" value="<?php echo $row['gender'];?>">
                    </div>
                    <div class="form-group">
                    <label>Address</label>
                    <textarea class="form-control"><?php echo $row['address'];?></textarea>
                    </div>
                    </div>
                  </form> 
                </div>
              </nav>
            </div>
</body>
</html>