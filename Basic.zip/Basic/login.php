<?php 
session_start();
$message="";
if(isset($_POST['login'])) {
$con = mysqli_connect('127.0.0.1','root','','sunny') or die('Unable To connect');
$result = mysqli_query($con,"SELECT * FROM register WHERE username='" . $_POST["username"] . "' and password = '". $_POST["password"]."'");
$row = mysqli_fetch_array($result);
if(isset($row)) {
$_SESSION['userid'] = $row['userid'];
$_SESSION['name'] = $row['username'];
} 
else 
{
$message = "<span class='alert alert-danger'> Invalid Username or Password!</span>";
}
}
if(isset($_SESSION["userid"])) {
header("Location:profile.php");
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>first php page</title>
     <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
  <script src="//ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-md-6">
          <div class="message"> <span id="username-availability-status"><?php if($message!="") { echo $message; } ?></span></div>
        <form method="post" name="loginForm" id="loginForm" action="">
    <div class="form-group">
       <input type="text" name="username" id="username" value="" class="form-control" placeholder="username" required />
    </div>
    <div class="form-group">
        <input type="password" name="password" class="form-control" placeholder="passsword" required="">
    </div>
    <div class="form-group">
        <input type="submit" name="login" class="btn btn-primary" value="login">
    </div>
  </form>
            </div>
        </div>
    </div>

</body>
</html>